# 🎵 Discord Music Bot

بوت موسيقى بسيط وشغال بدون embed.

## الأوامر
| الأمر | الوظيفة |
|---|---|
| `!play <اسم أو رابط>` | شغّل أغنية أو ابحث عنها |
| `!skip` | تخطى الأغنية الحالية |
| `!stop` | وقف وطلع من الروم |
| `!queue` | عرض قائمة الانتظار |
| `!help` | عرض الأوامر |

---

## إعداد البوت على Discord Developer Portal

1. روح [https://discord.com/developers/applications](https://discord.com/developers/applications)
2. اضغط **New Application** وسمّيه
3. من **Bot** → اضغط **Add Bot**
4. فعّل **Message Content Intent** (مهم!)
5. انسخ **Token** وحطه في ملف `.env`
6. من **OAuth2 > URL Generator**: اختر `bot` → اختر صلاحيات:
   - Send Messages, Read Messages, Connect, Speak
7. استخدم الرابط لتدخل البوت لسيرفرك

---

## تشغيل محلي

```bash
npm install
cp .env.example .env
# عدّل .env وحط التوكن
node index.js
```

---

## نشر على VPS (Ubuntu/Debian)

```bash
# 1. تثبيت Node.js 18+
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# 2. تثبيت ffmpeg (مهم للصوت!)
sudo apt-get install -y ffmpeg

# 3. استنسخ الريبو
git clone https://github.com/USERNAME/REPO_NAME.git
cd REPO_NAME

# 4. ثبّت المكتبات
npm install

# 5. أنشئ ملف .env
echo "DISCORD_TOKEN=توكنك_هنا" > .env

# 6. شغّله بـ pm2 (يخلّيه يشتغل دايم)
npm install -g pm2
pm2 start index.js --name music-bot
pm2 save
pm2 startup
```

### أوامر pm2 المفيدة
```bash
pm2 status          # شوف حالة البوت
pm2 logs music-bot  # شوف اللوقات
pm2 restart music-bot
pm2 stop music-bot
```
